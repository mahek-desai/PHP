<?php
session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
body {font-family: Helvetica;}
form {
  //border: 4px solid red;
  margin-right: 200px;
  margin-left: 200px;
  border-width: 4px;
}

input[type=text], input[type=password] {
  width: 50%;
  padding: 12px 20px;
  margin: 12px 0;
  display: inline-block;
  border: 2px solid black;
  box-sizing: border-box;
}

button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img{
  border-radius: 50%;
  border:3px solid black;
  width: 300px;
  height: 300px;
}

.container {
  padding: 16px;
  font-size: 18px;
}

span.psw {
  float: right;
  padding-top: 16px;
}
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<h1><center>LOGIN</center></h1>

<form method="post">
  <div class="imgcontainer">
    <img src="profile1.jpg">
  </div>

  <div class="container"><center>
    <label for="uname"><b><mark>Username</b></label>
    <input type="text" placeholder="Enter Username" name="uname" required>
    <br>
    <label for="psw"><b><mark>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
        
    <button type="submit" class='btn' name="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> <b><mark>Remember me
    </label>
  </div>
  </div>
</form>
  <?php
    if(isset($_POST['submit'])){
      if($_POST['uname']=="Admin"&&$_POST['psw']=="admin"){
        $_SESSION['uname']='Admin';
        $_SESSION['psw']='admin';
        header("location:menu.php");
      }
      else{
        echo "<script>alert('Please enter valid username and password!');</script>";
      }
    }
  ?>
</body>
</html>