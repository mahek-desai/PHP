<html>
     <head>
          <link rel="stylesheet" type="text/css" href="style.css">
          <link rel="stylesheet" href="style2.css">
     </head>
     <body>
          <form class="logout" method="POST">
               <input type="submit" class="t" name="logout" value="LOGOUT">
          </form>
          <?php
               if(isset($_POST["logout"]))
               {
                    session_destroy();
                    header("location:login.php");
                }
          ?>
          <form class="back" method="POST">
               <input type="submit" class="bac" name="back" value="BACK">
          </form>
          <?php
               if(isset($_POST["back"]))
               {
                    header("location:login.php");
                }
          ?>
          <div class="ma">
          
               
         <div class="d" align="center">
               <table align='center' cellpadding=10 cellspacing=10 border=0>
               <form method="post">
                    <tr>
                         <td></td>
                    </tr>
               <tr align="center">
                    <td><h1>Administator</h1></td>
               </tr>
               <tr>
                    <td><hr></td>
               </tr>

               <tr>
                         <td>
                         <input type="submit" class="btn" value="INSERT" name="insert" >
               </tr>
                    <tr>
                         <td>
                         <input type="submit" class="btn" value="UPDATE" name="update" >
                    </tr>
                    <tr>
                         <td>
                         <input type="submit" class="btn" value="DELETE" name="delete" >
                    </tr>     
                    <tr>
                         <td>
                         <input type="submit" class="btn" value="SEARCH" name="search" >
                    </tr>     
                    <tr>
                         <td>
                         <input type="submit" class="btn" value="DISPLAY" name="display" >
                    </tr>


                         </form>
                    </table>
          </div>          

</div>
     </body>
</html>
<?php
     if(isset($_POST["insert"]))
     {
          header("location:insert.php");
     }
     if(isset($_POST["update"]))
     {
          header("location:update.php");
     }
     if(isset($_POST["delete"]))
     {
          header("location:delete.php");
     }
     if(isset($_POST["search"]))
     {
          header("location:search.php");
     }
     if(isset($_POST["display"]))
     {
          header("location:display.php");
     }
?>