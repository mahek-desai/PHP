<?php
$conn=mysqli_connect("localhost","root","");
$db=mysqli_select_db($conn,"supermarket");
if($db)
{
     $q="desc info";
     $table=mysqli_query($conn,$q);
     if($table)
     {
          //echo'table available';
          $q="desc info";
     }
     else
          {
               
               $sql="CREATE TABLE info (
                    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    name varchar(25),
                    price float NOT NULL,
                    num int NOT NULL,
                    discount int NOT NULL
                    )" or die("aww");
               if(mysqli_query($conn,$sql))
               {
                    echo "table created";
               }
               else
               {
                    echo "not created";
               }
          }
     }
else
     {
          $q="CREATE DATABASE supermarket";
          if(mysqli_query($conn, $q))
          {
          $sql="CREATE TABLE info (
               id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
               name varchar(25),
               price float NOT NULL,
               num int NOT NULL,
               discount int NOT NULL
               )" or die("aww");
          }
     }
?>