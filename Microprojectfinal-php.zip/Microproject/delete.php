<html>
<head>
     <link rel="stylesheet" href="style2.css">
</head>
<body>
     <form class="logout" method="POST">
               <input type="submit" class="t" name="logout" value="LOGOUT">
          </form>
          <?php
               if(isset($_POST["logout"]))
               {
                    session_destroy();
                    header("location:login.php");
                }
          ?>
          <form class="back" method="POST">
               <input type="submit" class="bac" name="back" value="BACK">
          </form>
          <?php
               if(isset($_POST["back"]))
               {
                    header("location:menu.php");
                }
          ?>
</body>
</html>
<html>
     <head>
     <link rel="stylesheet" type="text/css" href="style.css">
     </head>
     <body>
<link rel="stylesheet" type="text/css" href="style.css">
<?php
include 'config.php';
		$sql = "SELECT * FROM info;";
		$result = mysqli_query($conn,$sql);
		echo"<div align=center><form method='POST'><table class=ta border=0>
		<tr align=center>
		<td class=te>ID</td>
		<td class=te>NAME</td>  
		<td class=te>PRICE</td>       
		<td class=te>AVAILABLE</td>
		<td class=te>DISCOUNT</td>
		<td class=te></td>
		</tr><br></center>";
	
		$i = 0;
		if(mysqli_num_rows($result)!=0)
		{
		while ($array = mysqli_fetch_array($result)) {
		    echo "<tr>";
		    echo "<td class=te>";
		    echo $array[0];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[1];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[2];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[3];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[4];
		    echo "</td>";
		    echo "<td class=te>";
		    echo "<a href='delete.php?ide=".$array[0]."'>Delete</a>";
		    echo "</td>";
			}
			echo"<tr><td align='center' colspan=6><input type=submit name='submit' class='btn' value='DELETE ALL RECORDS'>";
		}  
		else
		{
			echo "<tr><td class=te colspan=6>NO DATA FOUND!!";
		}
		?>
		<?php
		if(isset($_POST['submit']))
		{
			$t=0;
		include "config.php";
		$q="drop table info";
		$c=mysqli_query($conn,$q);
		if($c)
		{
			echo "<script>alert('ALL RECORDS DELETED!!');</script>";
			$t++;
		}
		if($t!=0)
		{
		header("location:menu.php");
		}
		}
		?>
	 <?php
	 if (isset($_GET['ide'])) {
		$t=0;
		$id = $_GET["ide"];
		$cn = mysqli_connect("localhost", "root", "") or die("Not connect");
		$a = mysqli_select_db($cn, "supermarket") or die("Not connect");
		$q = mysqli_query($cn, "delete from info where id=$id");
		if($q)
		{
			echo"<script>alert('ITEM DELETED!!');</script>";
			$t++;
		}
		else{
			echo"<script>alert('ITEM NOT DELETED!!');</script>";
		}
		if($t!=0)
		{
			echo"<script>window.location.href = 'menu.php';</script>";
		}
	 }
	 ?>
</body>
</html>