<html>
<head>
     <link rel="stylesheet" href="style2.css">
</head>
<body>
     <form class="logout" method="POST">
               <input type="submit" class="t" name="logout" value="LOGOUT">
          </form>
          <?php
               if(isset($_POST["logout"]))
               {
                    session_destroy();
                    header("location:login.php");
                }
          ?>
          <form class="back" method="POST">
               <input type="submit" class="bac" name="back" value="BACK">
          </form>
          <?php
               if(isset($_POST["back"]))
               {
                    header("location:menu.php");
                }
          ?>
</body>
</html>
<html>
     <head>
     <link rel="stylesheet" type="text/css" href="style.css">
     </head>

<body>
<form method="POST">

<div class="d" align="center">
<table align='center' cellpadding=10 cellspacing=10 border=0 class="ta">
     <tr class="">
          <td class="te"><p class="te">Name</p><td class="in"> <input type= "text" class="in" name="name"><br>
     <tr>
          <td class="te"><p class="te">Price</p><td class="in"> <input type= "number" class="in" name="price"><br>
     <tr>
          <td class="te"><p class="te">No. of item</p><td class="in"> <input type= "number" class="in" name="no"><br>
     <tr>
          <td class="te"><p class="te">Discount</p><td class="in"> <input type= "number" class="in" name="discount"><br>
     <tr>
          <tr><td colspan='2' align='center'><input type="submit" class="btn" name="submit" value="INSERT">
 </html>
 <?php
 if(isset($_POST['submit']))
 {   $t=0;
 include 'config.php';
     $nm=$_POST['name'];
     $p=$_POST['price'];
     $n=$_POST['no'];
     $d=$_POST['discount'];
     $sql="insert into info VALUES('','".$nm."','$p','$n','$d')";
     $q=mysqli_query($conn,$sql);
     if($q)
     {
          echo"<script>alert('ITEM ADDED!!');</script>";
          $t++;
     }
     else{
          echo"<script>alert('ITEM NOT ADDED!!');</script>";
     }
     if($t!=0)
     {
          echo"<script>window.location.href = 'menu.php';</script>";
     }
}
?>
     </body>
</html>