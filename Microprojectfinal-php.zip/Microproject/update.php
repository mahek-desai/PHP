<html>
<head>
     <link rel="stylesheet" href="style2.css">
</head>
<body>
     <form class="logout" method="POST">
               <input type="submit" class="t" name="logout" value="LOGOUT">
          </form>
          <?php
               if(isset($_POST["logout"]))
               {
                    session_destroy();
                    header("location:login.php");
                }
          ?>
          <form class="back" method="POST">
               <input type="submit" class="bac" name="back" value="BACK">
          </form>
          <?php
               if(isset($_POST["back"]))
               {
                    header("location:menu.php");
                }
          ?>
</body>
</html>
<html>
     <head>
     <link rel="stylesheet" type="text/css" href="style.css">
     </head>
     <body>
<link rel="stylesheet" type="text/css" href="style.css">
<?php
include 'config.php';
		$sql = "SELECT * FROM info;";
		$result = mysqli_query($conn,$sql);
		echo"<div align=center><table class=ta border=0>
		<tr align=center>
		<td class=te>ID</td>
		<td class=te>NAME</td>  
		<td class=te>PRICE</td>       
		<td class=te>AVAILABLE</td>
		<td class=te>DISCOUNT</td>
		<td class=te></td>
		</tr><br></center>";
	
		$i = 0;
  
		while ($array = mysqli_fetch_array($result)) {
		    echo "<tr>";
		    echo "<td class=te>";
		    echo $array[0];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[1];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[2];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[3];
		    echo "</td>";
		    echo "<td class=te>";
		    echo $array[4];
		    echo "</td>";
		    echo "<td class=te>";
		    echo "<a href='update1.php?ide=" . $array[0] . "'>Update</a>";
		    echo "</td>";
		}  
	 ?>
	 
</body>
</html>