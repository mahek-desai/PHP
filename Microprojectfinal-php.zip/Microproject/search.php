<html>
<head>
     <link rel="stylesheet" href="style2.css">
</head>
<body>
     <form class="logout" method="POST">
               <input type="submit" class="t" name="logout" value="LOGOUT">
          </form>
          <?php
               if(isset($_POST["logout"]))
               {
                    session_destroy();
                    header("location:login.php");
                }
          ?>
          <form class="back" method="POST">
               <input type="submit" class="bac" name="back" value="BACK">
          </form>
          <?php
               if(isset($_POST["back"]))
               {
                    header("location:menu.php");
                }
          ?>
</body>
</html>
<html>
     <head>
     <link rel="stylesheet" type="text/css" href="style.css">
     </head>
     <body>
          <form method="post">
          <div class="d" align="center">
               <br><br><br>
               <table>
                    <tr>
                    <td class="te"><p class="te">Name:</p>
                    <td class="in"><input type=text name='name' placeholder="Enter Product Name" class='in'><br>
                    <tr>
                         <td class="te" colspan=2 align='center'>
                              <input type="submit" name="submit" value="Search" class='btn1'>
               </table>
               <br><br>
<?php
     if(isset($_POST['submit']))
     {
          $t=0;
          $nm=$_POST['name'];
          include "config.php";
          $sql="select * from info";
          $result=mysqli_query($conn,$sql);
          
          while ($array = mysqli_fetch_array($result)) {
               if($nm==$array[1])
               {
                    $t++;
               echo "<table>";
               echo "<tr>";
               echo "<td class=te>";
               echo "Id ";
               echo "<td class=te>";
               echo$array[0];
               echo "</td>";
               echo "<tr>";
               echo "<td class=te>";
               echo "Name ";
               echo "<td class=te>";
               echo $array[1];
               echo "<tr>";
               echo "<td class=te>";
               echo "Price ";
               echo "<td class=te>";
               echo $array[2];
               echo "</td>";
               echo "<tr>";
               echo "<td class=te>";
               echo "Quantity ";
               echo "<td class=te>";
               echo $array[3];
               echo "</td>";
               echo "<tr>";
               echo "<td class=te>";
               echo "Discount ";
               echo "<td class=te>";
               echo $array[4];
               echo "</td>";
               }
          }
          if($t==0)
          {
               echo"<table><tr><td class=te>NO RECORD FOUND!!";
          }
     }
?>
